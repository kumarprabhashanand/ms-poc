package kpit.poc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import kpit.poc.model.Item;
import kpit.poc.model.ItemData;

@Service
public class ItemService {
	
	ItemData itemData = new ItemData();
	List<Item> items = itemData.getItems();
	
	public List<Item> getAllItems() {
		return items;
	}
	
	public Item getItemByID(int id) {
		return items.stream().filter(u -> u.getItemID()==id).findFirst().get();
	}
	
	public void addItem(Item item) {
		items.add(item);
	}
	
	public boolean updateItem(int id, Item item) {
		for(int i=0;i<items.size();i++) {
			if(items.get(i).getItemID()==id) {
				items.set(i, item);
				return true;
			}
		}
		return false;
	}
	
	public void deleteItem(int id) {
		items.removeIf(u -> u.getItemID() == id);
	}
}
