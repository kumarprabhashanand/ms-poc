package kpit.poc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import kpit.poc.model.Order;
import kpit.poc.model.OrderData;

@Service
public class OrderService {
	
	OrderData orderData = new OrderData();
	List<Order> orders = orderData.getOrders();
	
	public List<Order> getAllOrders() {
		return orders;
	}
	
	public Order getOrderByID(int id) {
		return orders.stream().filter(u -> u.getOrderID()==id).findFirst().get();
	}
	
	public void addOrder(Order order) {
		orders.add(order);
	}
	
	public boolean updateOrder(int id, Order order) {
		for(int i=0;i<orders.size();i++) {
			if(orders.get(i).getOrderID()==id) {
				orders.set(i, order);
				return true;
			}
		}
		return false;
	}
	
	public void deleteOrder(int id) {
		orders.removeIf(u -> u.getOrderID() == id);
	}
}