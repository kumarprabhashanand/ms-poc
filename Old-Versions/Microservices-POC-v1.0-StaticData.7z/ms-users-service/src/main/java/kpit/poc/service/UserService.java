package kpit.poc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import kpit.poc.model.User;
import kpit.poc.model.UserData;

@Service
public class UserService {
	UserData userData = new UserData();
	List<User> users = userData.getUsers();
	
	public List<User> getAllUsers() {
		return users;
	}
	
	public User getUserByID(int id) {
		return users.stream().filter(u -> u.getUserID()==id).findFirst().get();
	}
	
	public void addUser(User user) {
		users.add(user);
	}
	
	public boolean updateUser(int id, User user) {
		for(int i=0;i<users.size();i++) {
			if(users.get(i).getUserID()==id) {
				users.set(i, user);
				return true;
			}
		}
		return false;
	}
	
	public void deleteUser(int id) {
		users.removeIf(u -> u.getUserID() == id);
	}
}
