package kpit.poc.model;

public class Order {
	int orderID;
	int userID;
	ItemDetail itemDetails;
	public Order() {
		// TODO Auto-generated constructor stub
	}
	public Order(int orderID, int userID, ItemDetail itemDetails) {
		this.orderID = orderID;
		this.userID = userID;
		this.itemDetails = itemDetails;
	}
	public int getOrderID() {
		return orderID;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public ItemDetail getItemDetails() {
		return itemDetails;
	}
	public void setItemDetails(ItemDetail itemDetails) {
		this.itemDetails = itemDetails;
	}
}
