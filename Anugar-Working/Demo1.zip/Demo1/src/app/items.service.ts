import {HttpClient,HttpHeaders} from '@angular/common/http';
import {Http,Headers} from '@angular/http';
import {Injectable} from '@angular/core';
import {Item} from './item.model';

    const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    };
@Injectable()
export class ItemService{
    
    // url:string="http://d-7231.kpit.com:7073/items";
    url:string="http://10.10.11.70:7073/items";
    constructor(private http:HttpClient,private _http:Http){
     
    }

    createAuthorizationHeader(headers:Headers) {
   headers.append('Authorization', 'Basic ' +
      btoa('kpit:kpit123')); 
  }

    getItem(item:Item){
         return this._http.get(this.url+"/"+item.itemID);
    }
    getAllItems(){
       return this._http.get(this.url);
    }

    insertItem(item:Item){
    var headers = new Headers();
    this.createAuthorizationHeader(headers);
    headers.append('Content-Type', 'application/json');
    return this._http.post(this.url,JSON.stringify(item),{headers:headers});
    }

    deleteItem(item){
    var headers = new Headers();
    this.createAuthorizationHeader(headers);
    headers.append('Content-Type', 'application/json');
    return this._http.delete(this.url+"/"+item.itemID,{headers:headers});
    }

    updateItem(item:Item){
     var headers = new Headers();
    this.createAuthorizationHeader(headers);
    headers.append('Content-Type', 'application/json');
    return this._http.put(this.url+"/"+item.itemID,item,{headers:headers});
    }
}