import {Component,OnInit} from '@angular/core';
import {ItemService} from './items.service';
import {Item} from './item.model';
import {FormGroup,FormControl} from '@angular/forms'

@Component({
    selector:"app-item",
    templateUrl:'./item.component.html',
    providers:[ItemService]
})

export class ItemComponent implements OnInit{
    itemList:Item[];
    message;
    deleteMessage;
    updateMessage;
    item=new Item();
    insertForm;
    isAddItemActive:boolean=false;
    isDisplayActive:boolean=true;
    isEditItemActive:boolean=false;
    isDeleteItemActive:boolean=false;
    isSaveItemActive:boolean=false;
    constructor(private itemService:ItemService){
        this.insertForm=new FormGroup({
            name:new FormControl(),
            price:new FormControl(),
            description:new FormControl(),
            quantity:new FormControl()
        })
    }

    ngOnInit(){
        this.showAllItems();
    }

    reset(){
        this.isAddItemActive=false;
         this.isDisplayActive=false;
        this.isEditItemActive=false;
         this.isDeleteItemActive=false;
         this.isSaveItemActive=false;
    }

    showAllItems(){
        this.itemService.getAllItems().subscribe(result=>{
        this.itemList=result.json();
        // console.log(this.itemList);
        });
    }

    addItem(){
        // console.log(this.item);
        this.itemService.insertItem(this.item).subscribe(result=>{
        this.message=result;
        this.insertForm.reset();
        });
    }

    deleteItem(item:Item){
        //  console.log(item);
        this.itemService.deleteItem(item).subscribe(result=>{
        this.deleteMessage=result;
        this.showAllItems();
        });
    }

    editItem(item:Item){
        this.itemService.getItem(item).subscribe(result=>{
        this.item=result.json();
        this.isSaveItemActive=true;
        });
    }

    saveItem(){
        console.log(this.item);
       this.itemService.updateItem(this.item).subscribe(result=>{
        this.updateMessage=result;
        console.log(this.updateMessage);
        this.isSaveItemActive=false;
        this.showAllItems();
    }); 
    }

    changeView(index:number){
        switch(index){

            case 1:this.reset();
                    this.isAddItemActive=true;
                    this.message="";
                    this.deleteMessage="";
                    this.updateMessage="";
                    break;
            case 2:this.reset();
                    this.isEditItemActive=true;
                    this.message="";
                    this.deleteMessage="";
                    this.updateMessage="";
                    break;
            case 3:this.reset();
                    this.isDeleteItemActive=true;
                    this.message="";
                    this.deleteMessage="";
                    this.updateMessage="";
                    break;
            case 4:this.reset();
                    this.showAllItems();
                    this.isDisplayActive=true;
                    this.message="";
                    this.deleteMessage="";
                    this.updateMessage="";
                    break;

        }
    }

}