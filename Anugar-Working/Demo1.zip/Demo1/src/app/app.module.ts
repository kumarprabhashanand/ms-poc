import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'
import { AppComponent } from './app.component';
import {ItemComponent} from './item.component';
import {ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http'
@NgModule({
  declarations: [
    AppComponent,ItemComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,ReactiveFormsModule,HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
