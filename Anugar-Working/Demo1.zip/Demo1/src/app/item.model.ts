
export class Item{
    itemID:number;
    name:string;
    price:number;
    description:string;
    quantity:number;
}