package kpit.zuul.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

//@Controller
@RestController
public class ConsumerControllerClient {
	
	/*@Autowired
	private DiscoveryClient discoveryClient;*/
	
	@Autowired
	private LoadBalancerClient loadBalancerClient;
	
	@RequestMapping("/test")
	@HystrixCommand(fallbackMethod="getEmployeefb")
	public void getEmployee() {
		
		/*List<ServiceInstance> instances=discoveryClient.getInstances("employee-zuul-service");
		ServiceInstance serviceInstance=instances.get(0);*/
		
		ServiceInstance serviceInstance = loadBalancerClient.choose("employee-zuul-service");
		
		String baseURL=serviceInstance.getUri().toString();
		
		baseURL=baseURL+"/producer/employee";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		try {
			response = restTemplate.exchange(baseURL, HttpMethod.GET, getHeaders(), String.class);
		} catch (RestClientException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(response.getBody());
	}
	public void getEmployeefb() {
		System.out.println("Call Failed - fallback");
	}
	
	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
}
