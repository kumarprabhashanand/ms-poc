package kpit.zuul.model;

public class Employee {
	private String empID;
	private String name;
	private String designation;
	private double salary;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(String empID, String name, String designation, double salary) {
		super();
		this.empID = empID;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
	}
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
}
