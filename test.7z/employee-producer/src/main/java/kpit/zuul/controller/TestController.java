package kpit.zuul.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import kpit.zuul.model.Employee;

@RestController
public class TestController {
	
	@Value("${server.port}")
    private String portNumber;
	
	@RequestMapping(method=RequestMethod.GET, value="/employee")
	@HystrixCommand(fallbackMethod="errorHandler")
	public Employee getEmployee() {		
		Employee emp = new Employee("123", "Prabhash", portNumber, 12.01);
		return emp;
	}
	public Employee errorHandler() {
		Employee empError = new Employee("0","Error","Error",0.0);
		return empError;
	}
}
